import 'package:flutter/material.dart';
import 'shopping_list_screen.dart';
import 'recipe_detail_screen.dart';
import 'favorites_screen.dart';
import 'cooked_screen.dart';
import 'recipe_data.dart'; // Import the recipe data

class MealPlannerScreen extends StatelessWidget {
  // Function to get the meal for the current day
  Map<String, String> getTodayMeal() {
    int dayOfWeek = DateTime.now().weekday - 1; // Monday is 0, Sunday is 6
    return suggestedMeals[dayOfWeek];
  }

  @override
  Widget build(BuildContext context) {
    Map<String, String> todayMeal = getTodayMeal();

    return Scaffold(
      appBar: AppBar(title: Text('Indian Dishes')),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildSuggestedMeal(todayMeal, context),

            // Wrap sections inside a container with constraints
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 10.0),
              child: Column(
                children: [
                  _buildRecipeSection(
                      'Main Course', mainCourseRecipes, context),
                  _buildRecipeSection('Salads', saladRecipes, context),
                  _buildRecipeSection('Soups', soupRecipes, context),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestedMeal(Map<String, String> meal, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Suggested for You Today",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => RecipeDetailScreen(recipe: meal),
                ),
              );
            },
            child: Container(
              decoration: BoxDecoration(
                border: Border.all(color: Colors.grey, width: 1.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius:
                        BorderRadius.vertical(top: Radius.circular(8)),
                    child: Image.asset(
                      meal['image']!,
                      height: 150,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          meal['title']!,
                          style: TextStyle(
                              fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                        SizedBox(height: 5),
                        Row(
                          children: [
                            Icon(Icons.access_time,
                                size: 14, color: Colors.grey),
                            SizedBox(width: 4),
                            Text(
                              meal['time']!,
                              style:
                                  TextStyle(color: Colors.grey, fontSize: 12),
                            ),
                          ],
                        ),
                        SizedBox(height: 10),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton(
                              onPressed: () {
                                FavoritesScreen.addToFavorites(meal);
                                ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text("Added to Favorites")));
                              },
                              child: Text("Add to Favorites"),
                            ),
                            ElevatedButton(
                              onPressed: () {
                                CookedScreen.addToCooked(meal);
                                ScaffoldMessenger.of(context).showSnackBar(
                                    SnackBar(
                                        content: Text("Marked as Cooked")));
                              },
                              child: Text("Mark as Cooked"),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRecipeSection(String sectionTitle,
      List<Map<String, String>> recipes, BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10.0, horizontal: 8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            sectionTitle,
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics:
                NeverScrollableScrollPhysics(), // Prevents scrolling inside GridView
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 10, // Two columns
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
              childAspectRatio:
                  1, // Adjust ratio (increase to make cards shorter)
            ),
            itemCount:
                recipes.length > 20 ? 20 : recipes.length, // Limit to 20 items
            itemBuilder: (context, index) {
              return _buildRecipeCard(recipes[index], context);
            },
          ),
        ],
      ),
    );
  }

  Widget _buildRecipeCard(Map<String, String> recipe, BuildContext context) {
    return GestureDetector(
      onTap: () {
        // Navigate to the RecipeDetailScreen
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => RecipeDetailScreen(recipe: recipe),
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey, width: 1.5),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
              child: Image.asset(
                recipe['image']!,
                height: 100,
                width: double.infinity,
                fit: BoxFit.cover,
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(6.0),
              child: Text(
                recipe['title']!,
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
