import 'package:flutter/material.dart';

class ShoppingListScreen extends StatelessWidget {
  final Map<String, String> recipe;

  ShoppingListScreen({required this.recipe});

  @override
  Widget build(BuildContext context) {
    List<String> ingredients = recipe['ingredients']!.split(',');

    return Scaffold(
      appBar: AppBar(title: Text('Shopping List')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: ListView.builder(
          itemCount: ingredients.length,
          itemBuilder: (context, index) {
            return ListTile(
              title: Text(ingredients[index].trim()),
            );
          },
        ),
      ),
    );
  }
}
