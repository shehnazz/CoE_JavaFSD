import 'package:flutter/material.dart';
import 'shopping_list_screen.dart';
import 'recipe_detail_screen.dart';

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});

  static List<Map<String, String>> favoriteRecipes = [];

  static void addToFavorites(Map<String, String> recipe) {
    if (!favoriteRecipes.contains(recipe)) {
      favoriteRecipes.add(recipe);
    }
  }

  @override
  _FavoritesScreenState createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Favorites')),
      body: FavoritesScreen.favoriteRecipes.isEmpty
          ? Center(child: Text('Your favorite recipes will appear here.'))
          : ListView.builder(
              itemCount: FavoritesScreen.favoriteRecipes.length,
              itemBuilder: (context, index) {
                final recipe = FavoritesScreen.favoriteRecipes[index];
                return ListTile(
                  leading: Image.asset(recipe['image']!, width: 50, height: 50),
                  title: Text(recipe['title']!),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            RecipeDetailScreen(recipe: recipe),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
