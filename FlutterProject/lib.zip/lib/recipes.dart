// lib/recipes.dart

final List<Map<String, String>> recipes = [
  {
    'title': 'Chicken Shahi',
    'image': 'assets/images/chickenadobo.jpg',
    'time': '1h 30m',
    'ingredients': '2 lbs chicken (cut into serving pieces)\n'
        '3 dried bay leaves\n'
        '4 tbsp soy sauce\n'
        '6 tbsp white vinegar\n'
        '5 cloves garlic (crushed)\n'
        '1 ½ cups water\n'
        '1 tsp sugar (optional)\n'
        '¼ tsp salt (optional)\n'
        '1 tsp whole peppercorn',
    'instructions':
        '1. Marinate chicken with soy sauce and garlic for at least 1 hour.\n'
            '2. Heat oil in a pot and pan-fry the chicken for 2 minutes per side.\n'
            '3. Add the remaining marinade, water, bay leaves, and peppercorn. Bring to a boil and simmer for 30 minutes.\n'
            '4. Pour in vinegar, stir, and cook for another 10 minutes.\n'
            '5. Add sugar and salt if needed. Stir and turn off the heat.\n'
            '6. Serve hot and enjoy!'
  },
  {
    'title': 'Aloo Paratha',
    'image': 'assets/images/alooParatha.jpg',
    'time': '20m',
    'ingredients': '2 medium-sized potatoes (boiled & diced)\n'
        '1 tbsp oil (preferably mustard oil)\n'
        '1 tsp cumin seeds (jeera)\n'
        '1/2 tsp turmeric powder (haldi)\n'
        '1/2 tsp red chili powder\n'
        '1/2 tsp coriander powder\n'
        'Salt to taste\n'
        '1 tbsp chopped coriander leaves (for garnish)\n'
        '1/2 tsp lemon juice (optional, for tanginess)\n',
    'instructions':
        '1. Heat oil in a pan on medium flame.\n'
            '2. Add cumin seeds and let them crackle.\n'
            '3. Add boiled & diced potatoes and stir well.\n'
            '4. Sprinkle turmeric, red chili, coriander powder, and salt. Mix well.\n'
            '5. Cook for 3–5 minutes, stirring occasionally until potatoes turn slightly crispy.\n'
            '6. Turn off the flame, garnish with coriander leaves, and squeeze lemon juice if desired.\n'
            '7. Serve hot with chapati or as a side dish with dal-rice.\n'
  },
];
