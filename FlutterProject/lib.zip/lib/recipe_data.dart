final List<Map<String, String>> mainCourseRecipes = [
  {
    'title': 'Chicken Shahi',
    'image': 'assets/images/chickenadobo.jpg',
    'time': '1h 30m',
    'ingredients': '2 lbs chicken (cut into serving pieces)\n'
        '3 dried bay leaves\n'
        '4 tbsp soy sauce\n'
        '6 tbsp white vinegar\n'
        '5 cloves garlic (crushed)\n'
        '1 ½ cups water\n'
        '1 tsp sugar (optional)\n'
        '¼ tsp salt (optional)\n'
        '1 tsp whole peppercorn',
    'instructions':
        '1. Marinate chicken with soy sauce and garlic for at least 1 hour.\n'
            '2. Heat oil in a pot and pan-fry the chicken for 2 minutes per side.\n'
            '3. Add the remaining marinade, water, bay leaves, and peppercorn. Bring to a boil and simmer for 30 minutes.\n'
            '4. Pour in vinegar, stir, and cook for another 10 minutes.\n'
            '5. Add sugar and salt if needed. Stir and turn off the heat.\n'
            '6. Serve hot and enjoy!'
  },
  {
    'title': 'Aloo Paratha',
    'image': 'assets/images/alooParatha.jpg',
    'time': '20m',
    'ingredients': '2 medium-sized potatoes (boiled & diced)\n'
        '1 tbsp oil (preferably mustard oil)\n'
        '1 tsp cumin seeds (jeera)\n'
        '1/2 tsp turmeric powder (haldi)\n'
        '1/2 tsp red chili powder\n'
        '1/2 tsp coriander powder\n'
        'Salt to taste\n'
        '1 tbsp chopped coriander leaves (for garnish)\n'
        '1/2 tsp lemon juice (optional, for tanginess)\n',
    'instructions':
        '1. Heat oil in a pan on medium flame.\n'
            '2. Add cumin seeds and let them crackle.\n'
            '3. Add boiled & diced potatoes and stir well.\n'
            '4. Sprinkle turmeric, red chili, coriander powder, and salt. Mix well.\n'
            '5. Cook for 3–5 minutes, stirring occasionally until potatoes turn slightly crispy.\n'
            '6. Turn off the flame, garnish with coriander leaves, and squeeze lemon juice if desired.\n'
            '7. Serve hot with chapati or as a side dish with dal-rice.\n'
  },
  {
    'title': 'Poha (Flattened Rice)',
    'image': 'assets/images/poha.jpg',
    'time': '10m',
    'ingredients': '1 cup poha (flattened rice)\n'
        '1 tbsp oil\n'
        '1/2 tsp mustard seeds\n'
        '1 green chili (chopped)\n'
        '1 small onion (chopped)\n'
        '1/4 tsp turmeric powder\n'
        '1/2 tsp salt (or as per taste)\n'
        'Salt to taste\n'
        '1 tbsp peanuts (optional)\n'
        '1 tbsp lemon juice (optional)\n'
        '1 tbsp chopped coriander leaves (for garnish)\n',
    'instructions':
        '1. Rinse poha in water and drain. Set aside.\n'
            '2. Heat oil in a pan, add mustard seeds, and let them crackle.\n'
            '3. Add green chili and onion, sauté until onions are translucent.\n'
            '4. Add turmeric powder, salt, and peanuts. Mix well.\n'
            '5. Add poha and mix gently. Cook for 2–3 minutes.\n'
            '6. Add lemon juice and garnish with coriander leaves.\n'
            '7. Serve hot with tea or as a snack.\n'
  },
  {
    'title': 'Masala Dosa',
    'image': 'assets/images/dosa.jpg',
    'time': '45m',
    'ingredients': '1 cup rice (soaked for 4 hours)\n'
        '1/2 cup urad dal (soaked for 4 hours)\n'
        '1/2 tsp fenugreek seeds (soaked for 4 hours)\n'
        '1/2 tsp salt (or as per taste)\n'
        '1/2 cup water (for grinding)\n'
        '1 tbsp oil (for cooking)\n'
        '1/2 cup potato filling (boiled & mashed potatoes mixed with spices)\n'
        '1/2 tsp mustard seeds (for tempering)\n'
        '1/2 tsp cumin seeds (for tempering)\n'
        '1/2 tsp turmeric powder (for potato filling)\n'
        '1/2 tsp red chili powder (for potato filling)\n'
        'Salt to taste (for potato filling)\n'
        '1 tbsp chopped coriander leaves (for garnish)\n'
        '1 tbsp lemon juice (optional, for tanginess)\n',
        
    'instructions': '1. Soak rice, urad dal, and fenugreek seeds for 4 hours. Drain and grind to a smooth batter with water.\n'
        '2. Ferment the batter overnight or for 8 hours.\n'
        '3. Heat a non-stick pan, pour a ladleful of batter, and spread it in a circular motion.\n'
        '4. Drizzle oil around the edges and cook until golden brown.\n'
        '5. Place potato filling in the center, fold the dosa, and cook for another minute.\n'
        '6. Garnish with coriander leaves and serve hot with chutney or sambar.\n'
        '7. Enjoy your delicious masala dosa!\n'

  },
  {
    'title': 'Sinigang na Baboy',
    'image': 'assets/images/sinigang.jpg',
    'time': '1h 30m',
    'ingredients': '2 lbs pork belly (cut into cubes)\n'
        '1 onion (quartered)\n'
        '2 tomatoes (quartered)\n'
        '1 radish (sliced)\n'
        '1 eggplant (sliced)\n'
        '1 cup long green beans\n'
        '2 cups water\n'
        '2 tbsp fish sauce\n'
        '1 tbsp tamarind paste or 2–3 pieces of fresh tamarind\n'
        'Salt and pepper to taste\n',
    'instructions':
        '1. In a pot, combine pork, onion, tomatoes, and water. Bring to a boil.\n'
            '2. Reduce heat and simmer for about 30 minutes or until pork is tender.\n'
            '3. Add radish, eggplant, and long green beans. Cook for another 10 minutes.\n'
            '4. Stir in fish sauce and tamarind paste. Adjust seasoning with salt and pepper.\n'
            '5. Serve hot with steamed rice.\n'
  },
  {
    'title': 'Garlic Butter Shrimp',
    'image': 'assets/images/shrimp.jpg',
    'time': '30m',
    'ingredients': '1 lb shrimp (with shells, deveined)\n'
        '4 tbsp butter\n'
        '6 cloves garlic (minced)\n'
        '1 tbsp oyster sauce (optional)\n'
        '1 tbsp soy sauce\n'
        '1 tbsp sugar\n'
        '½ tsp ground black pepper\n'
        '1 tbsp lemon or calamansi juice\n'
        '1 tbsp chopped parsley or green onions (for garnish)\n',
    'instructions': '1. Melt Butter & Sauté Garlic: In a pan over medium heat, melt butter. Add minced garlic and sauté until fragrant.\n'
        '2. Cook the Shrimp: Add shrimp and cook for about 2 minutes per side until they turn pink.\n'
        '3. Season: Stir in oyster sauce, soy sauce, sugar, and black pepper.\n'
        '4. Add Sprite & Simmer: Pour in Sprite or 7-Up and let it simmer for 2–3 minutes, allowing the sauce to slightly thicken.\n'
        '6. Finish with Lemon Juice: Squeeze in lemon or calamansi juice and mix well.\n'
        '7. Garnish & Serve: Sprinkle with chopped parsley or green onions. Serve hot with steamed rice.\n'
  },
 
];

final List<Map<String, String>> saladRecipes = [
  {
    'title': 'Ensaladang Mangga',
    'image': 'assets/images/ensaladang_mangga.jpeg',
    'time': '20m',
    'ingredients': '2 green mangoes, peeled and sliced into strips\n'
        '1 tomato, diced\n'
        '1 onion, sliced thinly\n'
        '¼ cup shrimp paste (bagoong) or fish sauce\n'
        '½ teaspoon sugar (optional, to balance taste)\n'
        '¼ teaspoon ground black pepper\n',
    'instructions':
        '1. Prepare Ingredients: Peel and slice green mangoes into thin strips. Dice tomatoes and slice onions.\n'
            '2. Mix Everything: In a bowl, combine mangoes, tomatoes, and onions. Add shrimp paste or fish sauce, sugar (if using), and black pepper. Toss well to mix.\n'
            '3. Serve & Enjoy: Transfer to a serving plate and enjoy as a side dish with grilled or fried dishes!\n'
  },
  
  {
    'title': 'Macaroni Salad',
    'image': 'assets/images/macaroni.jpg',
    'time': '20m',
    'ingredients': '1 lb elbow macaroni\n'
        '1 ½ cups mayonnaise\n'
        '¾ cup shredded cheese\n'
        '5 tbsp sweet pickle relish\n'
        '¼ cup minced carrot\n'
        '½ cup raisins\n'
        '8 oz pineapple tidbits\n'
        '1 red bell pepper, minced\n'
        '1 green bell pepper, minced\n'
        'Salt to taste\n',
    'instructions': '1. Cook Macaroni: Boil macaroni according to package instructions and set aside.\n'
        '2. Prepare Chicken: Boil chicken breast for 15 minutes, let cool, then shred.\n'
        '3. Mix Ingredients: In a large bowl, combine macaroni, shredded chicken, mayonnaise, and all other ingredients. Toss until well blended.\n'
        '4. Chill & Serve: Season with salt, refrigerate for at least 2 hours, then serve cold. Enjoy!\n'
  },
  
  
  
  {
    'title': 'Kilawing Labanos at Baboy',
    'image': 'assets/images/kilawing.jpg',
    'time': '1h',
    'ingredients': '1 pound pork belly, cut into ½-inch strips\n'
        '1 pound pork liver, cut into ½-inch strips\n'
        '1 cup vinegar\n'
        'salt and pepper to taste\n'
        '1 tablespoon oil\n'
        '1 onion, peeled and sliced thinly\n'
        '4 cloves garlic, peeled and minced\n'
        '1 tablespoon fish sauce\n'
        '1 cup water\n'
        '2 bay leaves\n'
        '1 large labanos, peeled and cut into ½-inch strips\n',
    'instructions': '1. In a bowl, combine pork and ½ cup of the vinegar. Season with salt and pepper to taste. Marinate for about 30 minutes.\n'
        '2. In another bowl, combine liver and the remaining ½ cup vinegar. Season with salt and pepper to taste. Marinate for about 10 minutes.\n'
        '3. Drain pork and liver separately and reserve marinade. With hands, squeeze to extract excess liquid.\n'
        '4. In a pan over medium heat, heat oil. Add onions and garlic and cook until softened.\n'
        '5. Add pork and cook, stirring occasionally, until lightly browned.\n'
        '6. Add fish sauce and cook for about 1 to 2 minutes.\n'
        '7. Add the reserved vinegar marinade and bring to a boil, uncovered and without stirring, for about 3 to 5 minutes.\n'
        '8. Add water and bay leaves and bring to a boil, skimming scum that floats on top.\n'
        '9. Lower heat, cover, and continue to cook for about 25 to 30 minutes or until pork is tender.\n'
        '10. Add labanos and cook until half-done.\n'
        '11. Add liver, stirring gently to combine, and continue to cook for about 5 minutes or until liver is cooked through, labanos are tender yet crisp, and liquid is reduced.\n'
        '12. Season with salt and pepper to taste. Serve hot.\n'
  },
  
  {
    'title': 'Ubod Salad with Pineapple Vinaigrette Recipe',
    'image': 'assets/images/ubod.jpg',
    'time': '20m',
    'ingredients': '1/2 Cup Calamansi Juice\n'
        '4 tablespoons cane vinegar\n'
        '4 tablespoons sugar\n'
        'Pepper\n'
        '2 tablespoons sesame oilt\n'
        '2 tablespoons extra virgin olive oil\n'
        '1/2 kilo palm heart (ubod) julienned then soaked in cold water\n'
        '2 pieces pineapple peeled and diced\n'
        '1/4 Cup Cherry tomatoes halved\n'
        '1 piece orange eeled and sliced into roundsn'
        '4 sprigs cilantro (wansoy)\n'
        'black sesame seeds\n',
    'instructions':
        '1. Make the vinaigrette: Combine all ingredients in a bowl and whisk vigorously until blended. Season to taste. Chill until ready to use.\n'
            '2. Place three mounds of ubod on a serving platter. Scatter diced pineapples and cherry tomatoes all over. Place orange rounds on top and garnish with cilantro.\n'
            '3. Drizzle dressing all over. Sprinkle black sesame seeds on top.\n'
  },
  
  {
    'title': 'Lato (Sea Grapes) Salad',
    'image': 'assets/images/lato_salad.jpeg',
    'time': '15 min',
    'ingredients': '2 cups lato (sea grapes), rinsed and drained\n'
        '1 medium onion, chopped\n'
        '1 onion, chopped\n'
        '2 tomatoes, chopped\n'
        '1 thumb-sized ginger, minced\n'
        '¼ cup vinegar or calamansi juice\n'
        '½ teaspoon salt\n'
        '¼ teaspoon ground black pepper\n',
    'instructions': '1. Prepare Lato: Gently rinse the lato under cold water and drain well. Avoid soaking to maintain its natural crunch.\n'
        '2. Combine Ingredients: In a bowl, mix lato, onion, tomatoes, and ginger.\n'
        '3. Make Dressing: In a separate dish, mix vinegar (or calamansi juice), salt, and black pepper.\n'
        '4. Toss & Serve: Pour the dressing over the salad, toss gently, and serve immediately. Enjoy!\n'
  },
];

final List<Map<String, String>> soupRecipes = [
  {
    'title': 'Tinolang Manok',
    'image': 'assets/images/tinola.jpg',
    'time': '1h',
    'ingredients': '2 lbs. chicken cut into serving pieces\n'
        '1 cup malunggay leaves\n'
        '1 cup hot pepper leaves\n'
        '1/8 teaspoon ground black pepper\n'
        '6 cups water\n'
        '1 piece Knorr chicken cube\n'
        '1 piece onion sliced\n'
        '4 cloves garlic crushed and chopped\n'
        '3 thumbs ginger julienne\n'
        '2 tablespoons fish sauce patis\n'
        '3 tablespoons vegetable oil\n',
    'instructions': '1. Heat oil in a pot.\n'
        '2. Sauté garlic, onion, and ginger. Add the ground black pepper.\n'
        '3. When the onion starts to get soft, add the chicken. Cook for 5 minutes or until it turns light brown.\n'
        '4. Pour the water. Let boil. Cover and then set the heat to low. Boil for 40 minutes.\n'
        '5. Scoop and discard the scums and oil on the soup.\n'
        '6. Add the Knorr chicken cube and chayote or papaya. Stir. Cover and cook for 5 minutes.\n'
        '7. Put the malunggay and hot pepper leaves in the pot and pour the fish sauce in. Continue to cook for 2 minutes.\n'
        '8. Transfer to a serving bowl. Serve.\n'
        '9. Share and enjoy!\n'
  },
  {
    'title': 'Sinigang na Baboy',
    'image': 'assets/images/sinigang.jpg',
    'time': '2h',
    'ingredients': '2 pounds pork spare ribs, cut into 2-inch pieces\n'
        '8 cups water\n'
        '2 large tomatoes, quartered\n'
        '1 medium onion, peeled and quartered\n'
        '2 tablespoons fish sauce\n'
        '6 pieces gabi, (peeled and halved depending on size)\n'
        '1 6-inch radish (labanos), peeled and sliced to ½-inch thick half-rounds\n'
        '2 finger chilies (siling haba)\n'
        '½ bunch long beans (sitaw), ends trimmed and cut into 3-inch lengths\n'
        '1 eggplant, ends trimmed and sliced to ½-inch thick half-rounds 6 pieces okra, ends trimmed\n'
        '15 pieces large tamarind or 1 ½ (1.41 ounces each) packages tamarind base powder salt and pepper to taste\n'
        '1 bunch bok choy or pechay, ends trimmed and separated into leaves\n',
    'instructions': '1. Rinse pork ribs and drain well.\n'
        '2. In a pot over medium heat, combine pork and enough water to cover. Bring to a boil, skimming scum that accumulates on top.\n'
        '3. Once broth clears, add tomatoes, onion, and fish sauce. Lower heat and simmer for about 1 to 1 ½ hours or until meat is tender, adding more water as necessary to maintain about 8 cups.\n'
        '4. Add gabi and cook for about 4 to 6 minutes or until tender.\n'
        '5. Add chili peppers and radish. Continue to simmer for about 2 to 3 minutes.\n'
        '6. Add long beans. Continue to cook for about 2 minutes.\n'
        '7. Add eggplant and okra and cook for another 1 to 2 minutes.\n'
        '8. If using packaged tamarind base, add to the pot and stir until completely dissolved.\n'
        '9. Season with salt and pepper to taste.\n'
        '10. Add bok choy and continue to cook for about 1 minute. Serve hot.\n'
  },
 
 
  {
    'title': 'Filipino Chicken Macaroni Sopas',
    'image': 'assets/images/sopas.jpg',
    'time': '1h 40m',
    'ingredients': '▢1 lb. chicken skin removed\n'
        '2 ounces ham chopped\n'
        '1/2 lb elbow macaroni\n'
        '4 stalks celery minced\n'
        '1 medium yellow onion minced\n'
        '1 large carrot diced\n'
        '1 ½ cups chopped cabbage optional\n'
        '4 cups chicken broth\n'
        '6 cups water\n'
        '1 1/2 cup fresh milk or 14 oz. can evaporated milk\n'
        '3 tablespoons butter\n'
        'Salt and pepper to taste\n',
    'instructions': '1. Bring the water to a boil.\n'
        '2. Add the chicken. Boil the chicken in low to medium heat for 45 minutes or until tender.\n'
        '3. Remove the chicken and let cool. Set-aside the water used to boil the chicken. We’ll use this later.\n'
        '4. Once the chicken reaches room temperature, shred the meat using your hands. Discard (throw away) the bones.\n'
        '5. Meanwhile, heat a clean large cooking pot.\n'
        '6. Pour-in the butter and oil. Once the butter and oil becomes hot, sauté the onion, carrot, and celery for 3 minutes.\n'
        '7. Add the shredded chicken and chopped ham. Cook for 2 minutes.\n'
        '8. Pour-in the chicken broth and the remaining water used to boil the chicken. Stir and let boil. Simmer for 20 minutes.\n'
        '9. Add the elbow macaroni. Cook for 15 minutes. Add more water if needed.\n'
        '10. Pour-in the milk. Stir and let boil.\n'
        '11. Add salt and pepper to adjust the taste.\n'
        '12. Transfer to a serving bowl. Serve.\n'
        '13. Share and enjoy!\n'
  },
];

final List<Map<String, String>> suggestedMeals = [
  mainCourseRecipes[0], // Monday
  {
    'title': 'Humba',
    'image': 'assets/images/humba.jpg',
    'time': '2h',
    'ingredients':
        'Pork belly, soy sauce, vinegar, banana blossoms, garlic, brown sugar, black beans',
    'instructions':
        'Simmer pork belly with soy sauce, vinegar, garlic, banana blossoms, and black beans until tender.'
  }, // Tuesday
  mainCourseRecipes[2], // Wednesday
  mainCourseRecipes[3], // Thursday
  saladRecipes[0], // Friday
  saladRecipes[1], // Saturday
  soupRecipes[0], // Sunday
];
