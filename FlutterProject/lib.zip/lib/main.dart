import 'package:flutter/material.dart';
import 'cooked_screen.dart';
import 'meal_planner_screen.dart';
import 'recipe_detail_screen.dart';
import 'favorites_screen.dart';
import 'settings_screen.dart';
import 'shopping_list.dart'; // Import new shopping list screen
import 'recipes.dart'; // Import recipes

void main() {
  runApp(MealPlannerApp());
}

class MealPlannerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meal Planner',
      theme: ThemeData(primarySwatch: Colors.green),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int _selectedIndex = 0;

  late List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      MealPlannerScreen(),
      recipes.isNotEmpty ? RecipeDetailScreen(recipe: recipes[0]) : Container(),
      ShoppingListScreen(),
    ];
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _navigateToPage(BuildContext context, Widget page) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => page),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Meal Planner')),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.green),
              child: Text('Menu',
                  style: TextStyle(color: Colors.white, fontSize: 24)),
            ),
            ListTile(
              leading: Icon(Icons.home),
              title: Text('Home'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: Icon(Icons.restaurant_menu),
              title: Text('Recipes'),
              onTap: () => _navigateToPage(
                  context, RecipeDetailScreen(recipe: recipes[0])),
            ),
            ListTile(
              leading: Icon(Icons.shopping_cart),
              title: Text('Shopping List'),
              onTap: () => _navigateToPage(context, ShoppingListScreen()),
            ),
            ListTile(
              leading: Icon(Icons.favorite),
              title: Text('Favorites'),
              onTap: () => _navigateToPage(context, FavoritesScreen()),
            ),
            ListTile(
              leading: Icon(Icons.settings),
              title: Text('Settings'),
              onTap: () => _navigateToPage(context, SettingsScreen()),
            ),
            ListTile(
              leading: Icon(Icons.food_bank),
              title: Text('Cooked'),
              onTap: () => _navigateToPage(context, CookedScreen()),
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today), label: 'Meal Plan'),
          BottomNavigationBarItem(
              icon: Icon(Icons.restaurant_menu), label: 'Recipes'),
          BottomNavigationBarItem(
              icon: Icon(Icons.shopping_cart), label: 'Shopping List'),
        ],
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
      ),
    );
  }
}
