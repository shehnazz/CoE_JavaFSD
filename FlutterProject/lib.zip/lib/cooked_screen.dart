import 'package:flutter/material.dart';
import 'recipe_detail_screen.dart';

class CookedScreen extends StatefulWidget {
  const CookedScreen({super.key});

  static List<Map<String, String>> cookedRecipes = [];

  static void addToCooked(Map<String, String> recipe) {
    if (!cookedRecipes.contains(recipe)) {
      cookedRecipes.add(recipe);
    }
  }

  @override
  _CookedScreenState createState() => _CookedScreenState();
}

class _CookedScreenState extends State<CookedScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Cooked')),
      body: CookedScreen.cookedRecipes.isEmpty
          ? Center(child: Text('Your cooked recipes will appear here.'))
          : ListView.builder(
              itemCount: CookedScreen.cookedRecipes.length,
              itemBuilder: (context, index) {
                final recipe = CookedScreen.cookedRecipes[index];
                return ListTile(
                  leading: Image.asset(recipe['image']!, width: 50, height: 50),
                  title: Text(recipe['title']!),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) =>
                            RecipeDetailScreen(recipe: recipe),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
