import 'package:flutter/material.dart';
import 'package:project/cooked_screen.dart';
import 'shopping_list_screen.dart';
import 'favorites_screen.dart';

class RecipeDetailScreen extends StatelessWidget {
  final Map<String, String> recipe;

  const RecipeDetailScreen({required this.recipe, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(recipe['title']!),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Image.asset(
                recipe['image']!,
                height: 200,
                width: 200,
                fit: BoxFit.cover,
              ),
              SizedBox(height: 16),
              Text(
                'Ingredients',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                recipe['ingredients']!,
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 16),
              Text(
                'Instructions',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                recipe['instructions']!,
                style: TextStyle(fontSize: 16),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      FavoritesScreen.addToFavorites(recipe);
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Added to Favorites")));
                    },
                    child: Text("Add to Favorites"),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      CookedScreen.addToCooked(recipe);
                      ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(content: Text("Marked as Cooked")));
                    },
                    child: Text("Mark as Cooked"),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
