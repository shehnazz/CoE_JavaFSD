export class UserModal {
    constructor(public username: string, public email: string) { }
}